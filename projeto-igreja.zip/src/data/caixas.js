export default [
    
        {caixa: 1, abertura: 500, sangria: 150, debito: 1500, credito: 2500, dinheiro: 1550, pix: 1000},
        {caixa: 2, abertura: 1000, sangria: 300, debito: 3000, credito: 1500, dinheiro: 700, pix: 800},
        {caixa: 3, abertura: 800, sangria: 400, debito: 4000, credito: 650, dinheiro: 1500, pix: 500},
]