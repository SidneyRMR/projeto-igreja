export default [
    
        {fechamento: "10/9/2022", user_id: 1, caixa: 2, abertura: 500, venda: [
            {produto_id: 1, qde: 80, debito: 200, credito: 150, dinheiro: 50, pix: 0},
            {produto_id: 2, qde: 120, debito: 500, credito: 100, dinheiro: 200, pix: 100},
            {produto_id: 4, qde: 50, debito: 100, credito: 120, dinheiro: 110, pix: 150},
            {produto_id: 6, qde: 300, debito: 300, credito: 400, dinheiro: 120, pix: 130},
        ]},

        {fechamento: "9/9/2022", user_id: 3, caixa: 1, abertura: 500, venda: [
            {produto_id: 1, qde: 540, debito: 350, credito: 105, dinheiro: 50, pix: 180},
            {produto_id: 2, qde: 120, debito: 500, credito: 100, dinheiro: 200, pix: 100},
            {produto_id: 4, qde: 50, debito: 100, credito: 120, dinheiro: 110, pix: 150},
            {produto_id: 6, qde: 300, debito: 300, credito: 400, dinheiro: 120, pix: 130},
        ]},

        {fechamento: "8/9/2022", user_id: 2, caixa: 3, abertura: 600, venda: [
            {produto_id: 1, qde: 150, debito: 100, credito: 300, dinheiro: 500, pix: 10},
            {produto_id: 2, qde: 120, debito: 500, credito: 100, dinheiro: 100, pix: 1100},
            {produto_id: 4, qde: 50, debito: 100, credito: 120, dinheiro: 50, pix: 10},
            {produto_id: 6, qde: 300, debito: 300, credito: 400, dinheiro: 120, pix: 130},
        ]},
    
]
