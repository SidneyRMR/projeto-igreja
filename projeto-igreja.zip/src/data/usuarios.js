export default [
    {id:1, nome: "Ana Maria", login: "anamaria", senha: 1001, adm: 'false'},
    {id:2, nome: "Maria Galego", login: "mariagalego", senha: 2002, adm: 'false'},
    {id:3, nome: "Paulo Henrique", login: "paulohenrique", senha: 3003, adm: 'true'},

]