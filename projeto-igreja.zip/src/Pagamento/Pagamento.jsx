
export default props => {

    return(
        'Teste'
    )
}