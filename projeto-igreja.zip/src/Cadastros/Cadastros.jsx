
export default function(props) {

    return(
        <div className="borda">
            <a href="/cadastros/usuarios">Cadastrar Usuário</a>
            <a href="/cadastros/produtos">Cadastrar Produto</a><br />
            <a href="/abertura-caixa">Voltar</a>
        </div>
    )
}